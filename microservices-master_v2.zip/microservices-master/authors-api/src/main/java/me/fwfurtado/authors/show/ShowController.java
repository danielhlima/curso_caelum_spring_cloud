package me.fwfurtado.authors.show;

import static org.springframework.http.ResponseEntity.notFound;
import static org.springframework.http.ResponseEntity.ok;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("authors")
public class ShowController {

    @GetMapping("{id}")
    ResponseEntity<Author> show(@PathVariable Long id) {
        if (id == 1L) {
            return ok(new Author(1L, "Fernando"));
        }

        return notFound().build();
    }


    static class Author {
        private Long id;
        private String name;

        Author(Long id, String name) {
            this.id = id;
            this.name = name;
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }
}
