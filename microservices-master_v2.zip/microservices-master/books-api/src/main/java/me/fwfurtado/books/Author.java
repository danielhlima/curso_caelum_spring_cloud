package me.fwfurtado.books;

public class Author {

    private Long id;
    private String name;

    /**
     * @deprecated frameworks only
     */
    @Deprecated
    Author() {
    }

    public Author(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
