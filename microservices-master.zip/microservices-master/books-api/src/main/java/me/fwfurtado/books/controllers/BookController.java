package me.fwfurtado.books.controllers;

import static org.springframework.http.ResponseEntity.ok;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("books")
class BookController {

    private final long port;

    BookController(@Value("${server.port}") long port) {
        this.port = port;
    }

    @GetMapping("{id}")
    ResponseEntity<Book> show(@PathVariable Long id) {
        return ok().header("X-SERVER-PORT", Long.toString(port)).body(new Book(id, "Spring"));
    }

    static class Book {

        private Long id;
        private String title;

        Book(Long id, String title) {
            this.id = id;
            this.title = title;
        }

        public Long getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }
    }
}
